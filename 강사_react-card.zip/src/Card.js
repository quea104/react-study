import './Card.css';

import Label from "./components/Label";
import Square from "./components/Square";

function Card(props) {
    
  return (
    <div className="cardStyle">
      <Square color={props.color} />
      <Label color={props.color}/>
    </div>
  );
}

export default Card;

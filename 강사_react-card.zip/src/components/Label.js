import './Label.css';

const Label = (props) => {
    
  return (
    <p className="labelStyle">{props.color}</p>
  );
};

export default Label;
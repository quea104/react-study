

const ShopHeader = (props) => {

  console.log('ShopHeader rendering now..');


  return (
    <h1>{props.shopName} 쇼핑몰에 오신걸 {props.message}//합니다.</h1>
  );
}

export default ShopHeader;
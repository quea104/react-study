const ShopFooter = (props) => {

  console.log('ShopFooter rendering now..');

  return (
    <h3>Copyright 2022 by {props.whoMade}</h3>
  );
}

export default ShopFooter;
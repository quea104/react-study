import ShopContentList from "./ShopContentList";
import ShopContentTitle from "./ShopContentTitle";

function ShopContent(props) {
  console.log('ShopContent rendering now..');

  return (
    <>
      <ShopContentTitle/>
      <ShopContentList products={props.products}/>
    </>
  );
}

export default ShopContent;
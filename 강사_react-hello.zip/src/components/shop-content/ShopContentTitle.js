function ShopContentTitle() {
  return (
    <h3>상품 목록</h3>
  );

}

export default ShopContentTitle;
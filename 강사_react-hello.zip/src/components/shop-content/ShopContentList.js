function ShopContentList(props) {

  if (props.products.length === 0) {
    return (
      <ul>
        <li>상품이 없어요..</li>
      </ul>
    );
  }
  
  return (
    <ul>
      {
        props.products.map((product, index) => 
          <li key={index}>{product}</li>
        )
      }
    </ul>
  );
}

export default ShopContentList;
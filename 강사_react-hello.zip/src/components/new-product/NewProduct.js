import { useRef, useState } from "react";


const NewProduct = props => {

  const productButton = useRef(null);
  //let typedProduct = '';
  const [typedProduct, setTypedProduct] = useState('');
  

  const submitButtonHandler = (event) => {
    event.preventDefault();
    //setProducts([typedProduct, ...products]);
    // 입력한 상품을 아버지에게(App.js) 전달해야 한다.
    // typedProduct
    props.onProductAdd(typedProduct);
    setTypedProduct('');
    // TODO 인풋박스에 포커스를 준다
    productButton.current.focus();
  };

  const inputChangeHandler = (event) => {
    console.log(event.target.value);
    setTypedProduct(event.target.value);
  };

  return (
    <form onSubmit={submitButtonHandler}>
      <input type='submit' value='상품추가'/><br/><br/>
      <label>상품명 : </label>
      <input 
        type='text' 
        ref={productButton} 
        value={typedProduct} 
        onChange={inputChangeHandler}/>
        <div>{props.children}</div>
    </form>
  );

}

export default NewProduct;
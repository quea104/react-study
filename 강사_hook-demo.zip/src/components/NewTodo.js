import { useState } from "react";

function NewTodo(props) {

  const [todoId, setTodoId] = useState(0);
  const [body, setBody] = useState('');

  const idTextChangeHandler = (e) => {
    console.log(e.target.value);
    setTodoId(e.target.value);
  }
  const todoBodyChangeHandler = e => {
    console.log(e.target.value);
    setBody(e.target.value);
  }
  const formSubmitHandler = e => {
    e.preventDefault();
    console.log(todoId, body);
    props.onTodoAdded({todoId, body});
  }
  return (
    <>
      <form onSubmit={formSubmitHandler}>
        <div>
          todo id : <input type='text' onChange={idTextChangeHandler}></input>
        </div>
        <div>
          할일 : <input type='text' onChange={todoBodyChangeHandler}></input>
        </div>
        <div>
          <input type='submit' value='할일 추가하기'></input>
        </div>
      </form>
    </>
  );
}

export default NewTodo;
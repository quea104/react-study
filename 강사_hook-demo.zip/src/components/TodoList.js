function TodoList(props) {

  return (
    <>
      {/* <button onClick={fetchTodosFromFakeServer}>다시 가져오기</button> */}
      <ul>
        {props.todos.map(todo => 
          <li key={todo.id}>
            {todo.id}번 할일 : {todo.title} ({todo.completed ? '완료' : '미완료'})
          </li>
        )}
      </ul>
    </>
  );
}

export default TodoList;
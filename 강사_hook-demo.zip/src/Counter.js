import { useReducer } from "react";

function reducer(status, action) {
  switch (action.type) {
    case 'INCREASE':
      return {count: status.count + 1};
    case 'DECREASE':
      return {count: status.count - 1};
    default:
      return status;
  };
}

function Counter() {
  //const [number, setNumber] = useState(0);
  const [status, dispatch] = useReducer(reducer, {
    count: 0,
  });

  const increaseNumber = () => dispatch({ type: 'INCREASE'} );
  const decreaseNumber = () => dispatch({ type: 'DECREASE'} );
    
  return (
    <div>
      <button onClick={increaseNumber}>+</button>
      <button onClick={decreaseNumber}>-</button>
      <h3>{status.count}</h3>
    </div>
  );
}

export default Counter;
import axios from "axios";
import { useEffect, useReducer } from "react";
import NewTodo from "./components/NewTodo";
import TodoList from "./components/TodoList";

function reducer(state, action) {
  switch (action.type) {
    case 'LOADING':
      return {
        loading: true,
        data: null,
        error: null,
      };
    case 'SUCCESS':
      return {
        loading: false,
        data: action.data,
        error: null,
      };
    case 'APPEND':
      // 기존의 state 값에 NewTodo에서 전달된 todo object를 추가.. 반환
      return {
        loading: false,
        error: null,
        data: [
          action.data,
          ...state.data,
        ]
      };
    case 'ERROR':
      return {
        loading: false,
        data: null,
        error: action.error,
      };
    default:
      throw new Error(`unknown type ${action.type}`);
  }
}

function App() {

  const [state, dispatch] = useReducer(reducer, {
    data: null,
    loading: false,
    error: null,
  });

  // const [todos, setTodos] = useState(null);
  // const [loading, setLoading] = useState(false);
  // const [error, setError] = useState(null);

  // const [todoStatus, setTodoStatus] = useState({
  //   todos: null,
  //   loading: false,
  //   error: null,
  // });

  const fetchTodosFromFakeServer = async () => {
    try {
      dispatch({type: 'LOADING'});
      const res = await axios.get('https://jsonplaceholder.typicode.com/todos');
      dispatch({type: 'SUCCESS', data: res.data});
      console.log('fetch ok..');
    } catch (error) {
      console.log(error);
      dispatch({type: 'ERROR', error: error});
    }
  };

  const appendNewTodoHandler = e => {
    console.log('아버지가 할일 데이터 받았어요.. ', e);
    const todoToAppend = {
      id: parseInt(e.todoId),
      title: e.body,
      completed: false,
    };
    // state 에 추가하면 됨
    dispatch({type: 'APPEND', data: todoToAppend, })
  };

  useEffect(() => {
    fetchTodosFromFakeServer()
  }, []);

  const {loading, error, data: todos} = state;

  if (loading) return <div>로딩중..</div>
  if (error) return <div>에러가 발생했습니다.</div>
  if (!todos) return null;
  
  return (
    <>
      <h1>todo list</h1>
      <NewTodo onTodoAdded={appendNewTodoHandler}/>
      <TodoList todos={todos} />
    </>
  );
}

export default App;
